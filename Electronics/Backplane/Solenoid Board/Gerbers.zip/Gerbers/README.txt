
Contact Name: Luke McBee
Email : lmcbee@purdue.edu
phone number: (812) - 664 - 1442

Submission Date : January 6, 2016

Board Name :  Solenoid Driver Board

Largest X Dimension : 1.35 in

Largest Y Dimension : 1.22 in

Total Area: 1.647 in^2


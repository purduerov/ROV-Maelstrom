Contact info
Name: Rodolfo Leiva
email: rleiva@purdue.edu
Phone: (765) 426-9452

Date submitted: 1/16/2016
Board Name: Application Board
Size: 2.7 X 2.08 inch
Total Area: 5.616 sq. inch

*If you run into any problems please contact me.

Contact Name: Luke McBee
Email : lmcbee@purdue.edu
phone number: (812) - 664 - 1442

Submission Date : January 6, 2016

Board Name : Step Down Buck Regulator Board

Largest X Dimension : 1.8 in

Largest Y Dimension : 2.1 in

Total Area: 3.78 in^2


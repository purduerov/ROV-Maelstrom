
Contact Name: Luke McBee
Email : lmcbee@purdue.edu
phone number: (812) - 664 - 1442

Submission Date : January 6, 2016

Board Name :  

Largest X Dimension : 4 in

Largest Y Dimension : 4 in

Total Area: 13.25 in^2

Special Notes:  The shape of the board is a regular octogon
